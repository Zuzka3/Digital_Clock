// js/app.js
const API_ENDPOINTS = {
    weather: (query = '') => `/api/weather${query ? `?q=${encodeURIComponent(query)}` : ''}`,
};

const app = Vue.createApp({
    data() {
        return {
            currentTime: '00:00:00',
            currentDate: 'Načítání data...',
            weather: {
                city: null,
                temp: null,
                description: null,
                iconUrl: null,
                wind_speed: null,
                humidity: null,
                forecast: []
            },
            locationSource: null,
            isLoading: true,
            error: null,
            isDarkMode: null,
            timeUpdateInterval: null,
            weatherUpdateInterval: null,
            modeUpdateInterval: null,
            previousMinutes: -1,
        }
    },
    computed: {
        locationStatusText() {
            if (!this.weather.city) return '...';
            const sourceText = this.locationSource === 'geo' ? '(přesněji)' : '(přibližně)';
            return `${this.weather.city} ${sourceText}`;
        },

        appClasses() {
            console.log(`[Computed:appClasses] Calculating classes. isDarkMode is: ${this.isDarkMode}`);
            return {
                'dark-mode': this.isDarkMode,

            };
        }
    },
    methods: {
        formatForecastDate(dateString) {
            const date = new Date(dateString + 'T00:00:00');
            return date.toLocaleDateString('cs-CZ', {
                weekday: 'short',
                day: 'numeric',
                month: 'numeric'
            });
        },
        getIconUrl(iconPath) {
            if (!iconPath) return '';
            return iconPath.startsWith('//') ? `https:${iconPath}` : iconPath;
        },
        getForecastIconUrl(iconPath) {
            return this.getIconUrl(iconPath);
        },
        getBrowserLocation() {
            return new Promise((resolve, reject) => {
                if (!navigator.geolocation) reject("Geolocation API není v tomto prohlížeči podporováno.");
                else navigator.geolocation.getCurrentPosition(
                    (position) => resolve({
                        latitude: position.coords.latitude,
                        longitude: position.coords.longitude
                    }),
                    (error) => {
                        console.error("Chyba při získávání polohy z prohlížeče:", error);
                        let message = "Nepodařilo se získat polohu.";
                        if (error.code === 1) message = "Povolení pro zjištění polohy bylo zamítnuto.";
                        else if (error.code === 2) message = "Informace o poloze nejsou dostupné.";
                        else if (error.code === 3) message = "Vypršel čas pro zjištění polohy.";
                        reject(message);
                    }, {
                    enableHighAccuracy: false,
                    timeout: 10000,
                    maximumAge: 0
                }
                );
            });
        },
        async fetchWeatherApi(query = '') {
            const apiUrl = API_ENDPOINTS.weather(query);
            console.log(`[API] Fetching weather from: ${apiUrl}`);
            try {
                const response = await fetch(apiUrl);
                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({
                        error: `HTTP ${response.status}`
                    }));
                    throw new Error(errorData.error || `Chyba ${response.status}`);
                }
                console.log(`[API] Weather fetch successful for: ${query || 'IP Fallback'}`);
                return await response.json();
            } catch (error) {
                console.error(`[API] Error fetching weather (${query || 'IP Fallback'}):`, error);
                throw error;
            }
        },
        async fetchData() {
            console.log("[Weather] Starting data fetch sequence...");
            this.isLoading = true;
            this.error = null;
            let rawWeatherData;
            try {
                console.log("[Weather] Attempting Geolocation API...");
                const coords = await this.getBrowserLocation();
                console.log("[Weather] Geolocation successful.", coords);
                this.locationSource = 'geo';
                rawWeatherData = await this.fetchWeatherApi(`${coords.latitude},${coords.longitude}`);
                console.log("[Weather] Weather fetched via Geolocation.");
            } catch (locationError) {
                console.warn(`[Weather] Geolocation failed: ${locationError}. Falling back to IP.`);
                this.locationSource = 'IP';
                try {
                    rawWeatherData = await this.fetchWeatherApi();
                    console.log("[Weather] Weather fetched via IP fallback.");
                } catch (ipWeatherError) {
                    console.error("[Weather] IP fallback weather fetch failed:", ipWeatherError);
                    this.error = `Nepodařilo se načíst data o počasí: ${ipWeatherError.message}`;
                    this.isLoading = false;
                    this.weather = {
                        city: null,
                        temp: null,
                        description: null,
                        iconUrl: null,
                        wind_speed: null,
                        humidity: null,
                        forecast: []
                    };
                    return;
                }
            }
            this.weather = {
                city: rawWeatherData.city,
                temp: rawWeatherData.temp,
                description: rawWeatherData.description,
                iconUrl: this.getIconUrl(rawWeatherData.icon),
                wind_speed: rawWeatherData.wind_speed,
                humidity: rawWeatherData.humidity,
                forecast: rawWeatherData.forecast || []
            };
            this.isLoading = false;
            console.log("[Weather] Data update complete.", this.weather);
            this.$nextTick(() => {
                console.log("[Animation] Animating weather info and forecast...");
                this.animateWeatherInfo();
                this.animateForecast();
            });
        },
        updateTimeAndDate() {
            const now = new Date();
            const timeZone = Intl.DateTimeFormat().resolvedOptions().timeZone;
            this.currentTime = now.toLocaleTimeString('cs-CZ', {
                timeZone
            });
            this.currentDate = now.toLocaleDateString('cs-CZ', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                timeZone
            });
            const currentMinutes = now.getMinutes();
            if (currentMinutes !== this.previousMinutes) {
                let targetColor = this.isDarkMode ? '#f8f9fa' : '#343a40';
                if (currentMinutes === 0) targetColor = '#f5d442';
                else if (currentMinutes % 10 === 0) targetColor = '#e94560';
                if (this.$refs.timeElement) this.animateTime(this.$refs.timeElement, targetColor);
                this.previousMinutes = currentMinutes;
            }
        },
        animateTime(element, color) {
            gsap.fromTo(element, {
                scale: 0.98,
                opacity: 0.9
            }, {
                scale: 1,
                opacity: 1,
                color: color,
                duration: 0.4,
                ease: "power1.out"
            });
        },
        animateWeatherInfo() {
            const infoElements = document.querySelectorAll('.info-container .weather, .info-container .wind, .info-container .humidity');
            if (infoElements.length > 0) gsap.fromTo(infoElements, {
                opacity: 0,
                y: 10
            }, {
                opacity: 1,
                y: 0,
                duration: 0.5,
                stagger: 0.1,
                ease: "power1.out",
                overwrite: "auto"
            });
        },
        animateForecast() {
            const forecastItems = document.querySelectorAll('.forecastlist li');
            if (forecastItems.length > 1) gsap.fromTo(forecastItems, {
                opacity: 0
            }, {
                opacity: 1,
                duration: 0.5,
                stagger: 0.1,
                delay: 0.2,
                overwrite: "auto"
            });
        },

        setModeBasedOnTime() {
            const currentHour = new Date().getHours();
            const shouldBeDark = (currentHour >= 17 || currentHour < 6);

            console.log(`[Mode Check] Current hour: ${currentHour}. Should be dark? ${shouldBeDark}. Current isDarkMode before change: ${this.isDarkMode}`);

            if (this.isDarkMode !== shouldBeDark) {
                this.isDarkMode = shouldBeDark;
                console.log(`[Mode Check] >>> isDarkMode was changed to: ${this.isDarkMode}`);
            } else {
                console.log(`[Mode Check] isDarkMode already ${this.isDarkMode}, no change needed.`);
            }
        }
    },
    mounted() {
        console.log("[Lifecycle] Vue app mounted (targeting #app).");
        this.setModeBasedOnTime(); 
        console.log(`[Lifecycle] Initial mode check complete. isDarkMode is now: ${this.isDarkMode}`);
        this.updateTimeAndDate();
        this.fetchData();
        console.log("[Intervals] Setting up intervals...");
        this.timeUpdateInterval = setInterval(this.updateTimeAndDate, 1000);
        this.weatherUpdateInterval = setInterval(this.fetchData, 5 * 60 * 1000);
        this.modeUpdateInterval = setInterval(this.setModeBasedOnTime, 60 * 60 * 1000);
    },
    beforeUnmount() {
        console.log("[Lifecycle] Vue app unmounting, clearing intervals...");
        clearInterval(this.timeUpdateInterval);
        clearInterval(this.weatherUpdateInterval);
        clearInterval(this.modeUpdateInterval);
    }
});

// Stále mountujeme na #app
app.mount('#app');